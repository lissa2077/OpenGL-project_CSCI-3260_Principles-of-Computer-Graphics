It is whack-a-mole game. 
Strike all moles and they will respawn.

Selectbox Movement:
- W / Up : Move the selectbox up
- S / Down : Move the selectbox down
- A / Left : Move the selectbox left
- D / Right : Move the selectbox right
- Q : Strike a mole, the mole which is in selectbox will disappear

Moles Appearance Change:
- R / T : Rotate all appeared moles in the screen
(R: rotate left, T: rotate right)
- F / G : Scale all appeared moles in the screen
(F: smaller, G: bigger)

Camera Viewpoint Movement:
- Z / X : Move the camera view
(Z: move down, X: move up)